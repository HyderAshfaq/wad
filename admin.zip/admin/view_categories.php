<div class="row">
    <div class="col-sm-12">
        <h1>Category</h1>
        <table class="table table-striped">
            <thead>
            <tr>
                <th scope="col">#</th>
                <th scope="col">Title</th>
            </thead>
        <tbody>
        <?php
        $get_cat = "select * from categories";
        $run_cat = mysqli_query($con,$get_cat);
        $count_pro = mysqli_num_rows($run_cat);
        if($count_pro==0){
            echo "<h2> No Product found in selected criteria </h2>";
        }
        else {
            $i = 0;
            while ($row_cat = mysqli_fetch_array($run_cat)) {
                $cat_title = $row_cat['cat_title'];
                ?>
                <tr>
                    <th scope="row"><?php echo ++$i; ?></th>
                    <td><?php echo $cat_title; ?>/-</td>

                </tr>
                <?php
            }
        }
        ?>
        </tbody>
    </div>
    </table>
</div>